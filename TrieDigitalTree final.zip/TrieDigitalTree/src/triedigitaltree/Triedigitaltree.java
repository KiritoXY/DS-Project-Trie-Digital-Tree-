package triedigitaltree;



import java.io.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

public class Triedigitaltree     {
    
    public static int words=0;
    public class Node
    {
        public char data;
        Node [] next=new Node[26];
        Boolean isEndOfWord=false;
        Node(){
            data=0;
            for(int i=0; i<26; i++){
                next[i]=null;
            }
        }
        Node(char d){        
            data=d;
            for(int i=0; i<26; i++){
                next[i]=null;
            }
        }
                                                                                    
    }
    protected Node head=new Node(' ');
    protected int size; 
    
    Triedigitaltree()
    {
        size=0;
    }
    public void insert(String data)
    {
        data=data.toLowerCase();Boolean inserted=false;
        data=data.replaceAll("[^a-z]","");
        System.out.println(data+ " ");
        char letter;int index;
        Node CurrentNode=head;
        for(int i=0; i<data.length(); i++)
        {
            letter=data.charAt(i);
            index=getindex(letter);
            if(CurrentNode.next[index] == null)
            {
                Node newnode= new Node(letter);
                CurrentNode.next[index]=newnode;
            }
            if(i == data.length()-1 && CurrentNode.next[index].isEndOfWord != true)
            {
                words++;
                CurrentNode.next[index].isEndOfWord=true;
            }
            CurrentNode=CurrentNode.next[index];
        }
    }

public int getindex(char t)
    {
        return((int)t-97);
    }

public boolean search(String data)
    {
        data=data.toLowerCase();
        if(data.contentEquals(""))    return false;
        for(int i=0;i<data.length();i++)
        {
            if(data.charAt(i) < 97 || data.charAt(i) > 122)
            {
                System.out.println(data + " not found");
                return false;
            }
        }
        Node x=head;
        System.out.println(data);
        boolean found=false;
        int foundcharacters=0;
        int index=getindex(data.charAt(0));
        if(x.next[index]!=null)
        {
            x=x.next[index];
            foundcharacters++;
            for(int i=1;i<data.length();i++)
            {
                index=getindex(data.charAt(i));
                x=x.next[index];
                if(x!=null)
                {
                    foundcharacters++;
                }
                else
                {
                    System.out.println(data + " not found");
                    return false;
                }
            }
            if(foundcharacters==data.length())
            {
                System.out.println(data+" found");
                words+=1;
                return true;
            }
        }
        else
        {
            System.out.println(data + " not found");
            return false;
        }
        return false;
    }

 
    public boolean checkingLinks(Node current){
        boolean flag=true;
        for(int i=0; i<26; i++){
            if(current.next[i]!=null){
                flag=false;
                break;
            }
            
        }
        return flag;
    }
    int counter=0;
    public void delete(String data){
        deleted=false;
        count++;
        data=data.toLowerCase();
        data=data.replaceAll("[^a-z]","");
        counter=0;
        deleteHelper(data, head, 0);   
        if(deleted){
            System.out.println("Deleted "+ data);
            words+=1;
        }
        else    System.out.println("Word not found for deletion "+ data);
    }
     boolean deleted=false;static int count=-1;
    public boolean deleteHelper(String data, Node current, int index){
        boolean deleteIt=false;
        
        for(int i=0; i<26; i++){
           if(current.next[i]!=null){
               if(counter==data.length()){
                    return true;   
                }
               
                if(current.next[i].data== data.charAt(index)){
                   counter+=1;
                   deleteIt=deleteHelper(data, current.next[i], ++index);
                   if(deleteIt){
                       if(checkingLinks(current.next[i])){
                            current.next[i]=null;
                            deleted=true;
                       } 
                       else{
                            deleted=true;
                            current.next[i].isEndOfWord=false;
                       }
                       
                       if(!(current.isEndOfWord) && checkingLinks(current)){
                           return true;
                       }
                       else{
                           return false;
                       }
                   }
               } 
           }

           if(counter == data.length()){
               
               if((current.isEndOfWord==true)&& checkingLinks(current)){
                   
                   return true;
               }
               else{
                    return false;
               }
           }
            //break;
        }
        return false;
        
    }
    static String fileName;
    public String getFromFile(String fileName) {
        try{
           String allData="";
            
            FileInputStream fis=new FileInputStream(fileName);
            XWPFDocument docx= new XWPFDocument(fis);
            List <XWPFParagraph> paragraphList=docx.getParagraphs();
            for(XWPFParagraph para: paragraphList){
                allData+=" "+para.getText();
            }
           
           return allData;
        }
         catch( IOException e){
             System.out.println("file opening error!!");       
             return "";
         }
    }
    public static void main(String[] args) {
        Triedigitaltree a = new Triedigitaltree();
        String allData="";int totalwords=-2;
        
        //____insertion_____
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter File name:");
        fileName=scan.nextLine();
        fileName+=".docx";
        allData=a.getFromFile(fileName);
        allData=allData.replaceAll("\n"," ");
        long startTime=System.currentTimeMillis(); 
        for(String word: allData.split(" ")){
            totalwords++;
            a.insert(word);
        }
        long endTime=System.currentTimeMillis();        
        System.out.println("____________________");
        System.out.println("File Name:"+fileName);
        System.out.println("Total Words: "+totalwords);
        System.out.println("Words Inserted: "+words);
        System.out.println("Time taken: "+(endTime-startTime));
        /*
        //____deletion_____
        words=0;
        totalwords=-1;
        scan=new Scanner(System.in);
        System.out.println("Enter File name:");
        fileName=scan.nextLine();
        fileName+=".docx";
        
        allData=a.getFromFile(fileName);
        allData=allData.replaceAll("\n", " ");
        long startTime1=System.currentTimeMillis(); 
        for(String word: allData.split(" ")){
            totalwords++;
            a.delete(word);
        }
        long endTime1=System.currentTimeMillis();
        System.out.println("____________________");
        System.out.println("File Name:"+fileName);
        System.out.println("Total Words: "+totalwords);
        System.out.println("Words Deleted: "+words);
        System.out.println("Time taken: "+(endTime1-startTime1));
        */
        //____Searching_____
        words=0;
        totalwords=-1;
        scan=new Scanner(System.in);
        System.out.println("Enter File name:");
        fileName=scan.nextLine();
        fileName+=".docx";
        
        allData=a.getFromFile(fileName);
        allData=allData.replaceAll("\n", " ");
        long startTime2=System.currentTimeMillis(); 
        for(String word: allData.split(" ")){
            totalwords++;
            a.search(word);
        }
        long endTime2=System.currentTimeMillis();
        System.out.println("____________________");
        System.out.println("File Name:"+fileName);
        System.out.println("Total Words: "+totalwords);
        System.out.println("Words Searched: "+words);
        System.out.println("Time taken: "+(endTime2-startTime2));
    }
    
}

