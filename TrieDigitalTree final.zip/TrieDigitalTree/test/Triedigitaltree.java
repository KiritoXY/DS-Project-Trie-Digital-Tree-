


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

    public class Triedigitaltree 
    {
    protected Node head=new Node(' ');
    protected int size;
    
    Triedigitaltree()
    {
        size=0;
    }
    public class Node
    {
        public char data;
        Node [] next=new Node[26];
        Boolean isEndOfWord=false;
        Node()
        {
            data=0;
            for(int i=0; i<26; i++){
                next[i]=null;
            }
        }
        Node(char d)
        {        
            data=d;
            for(int i=0; i<26; i++){
                next[i]=null;
            }
        }
                                                                                    
    }
    public void insert(String data)
    {
        char letter;
        Node CurrentNode=head;
        for(int i=0; i<data.length(); i++)
        {
            letter=data.charAt(i);
            for(int j=0;j<26;j++)
                if(CurrentNode.next[j]== null)
                {
                        Node newnode= new Node(letter);
                        CurrentNode.next[j]=newnode;
                        CurrentNode=CurrentNode.next[j];
                        break;
                }
                else if(CurrentNode.next[j].data == letter)
                {
                    CurrentNode=CurrentNode.next[j];
                    break;
                }
                if(i == data.length()-1)
                {
                    CurrentNode.isEndOfWord=true;
                }
        }
    }
/*    boolean search(String v)
    {
        int p=0;
        char first=v.charAt(p);
        int milgya=0;
        Node temp=head;
        int i=0;
        while(i<26 || temp.data!=first )
        {
            if(temp==null || first==' ' || v==null)
            {
                return false;
            }
            if(temp.data!=first)
            {
                temp=temp.next[i];
                i=i+1;
            }
            else
            {
                p=p+1;
                first=v.charAt(p);
                milgya=milgya+1;
                i=0;
            }
        if(milgya==v.length())
        {
            return true;
        }
        }
        return false;
    }*/
    /*
    boolean search(String v)
    {
        int p=0,i=0,h=0;
        Node r=head;Node temp=r.next[h];Node vidividi;
        boolean milgya=false;
        char f=v.charAt(0);char t=temp.data;
        while(i<26 || temp.next[0]!=null)
        {
            if(t!=f)
            {
                if(h<24)
                {
                h=h+1;
                temp=r.next[h];
                t=temp.data;
                i=i+1;
                }
            }
            else
            {
                p=p+1;
                if(p<v.length())
                {
                    f=v.charAt(p);h=0;
                }
                else
                {
                    if(temp.next[0]==null)
                    {
                    milgya=true;
                    return milgya;
                    }
                    else
                    {
                        milgya=false;
                        return milgya;
                    }
                }
                vidividi=temp;
                i=0;
                temp=temp.next[i];
                t=temp.data;
                r=vidividi;
                
            }
            
        }
        return false;
    }
    */
public void search(String data)
{
    char letter;Boolean found=false;
        Node CurrentNode=head;
        for(int i=0; i<data.length(); i++)
        {
            letter=data.charAt(i);
            for(int j=0;j<26;j++)
                if(CurrentNode.next[j] != null)
                {
                    if(CurrentNode.next[j].data == letter)
                    {
                        CurrentNode=CurrentNode.next[j];
                        if(i == data.length()-1)
                        {
                            if(CurrentNode.isEndOfWord==true)
                            {
                                found=true;
                                j=27;i=data.length()+1;
                            }
                            else
                            {
                                j=27;i=data.length()+1;
                            }
                        }
                        break;
                    }
                }
                else
                {
                    j=27;i=data.length()+1;
                }
        }
        if(found)
        {
            System.out.println("Found in trie");
        }
        else
        {
            System.out.println("Not Found in trie");
        }
}
    
    public boolean checkingLinks(Node current){
        boolean flag=true;
        for(int i=0; i<26; i++){
            if(current.next[i]!=null){
                flag=false;
                break;
            }
            
        }
        return flag;
    }
    int counter=0;
    public void delete(String data){
        deleteHelper(data, head, 0);   
    }
    public boolean deleteHelper(String data, Node current, int index){
        boolean deleteIt=false;
        for(int i=0; i<26; i++){
           if(current.next[i]!=null){
                if(current.next[i].data== data.charAt(index)){
                   counter+=1;
                   deleteIt=deleteHelper(data, current.next[i], ++index);
                   if(deleteIt){
                       System.out.println("here");
                       current.next[i]=null;
                       if(!(current.isEndOfWord==true)&& checkingLinks(current))
                       {
                           return true;
                       }
                       else
                       {
                           return false;
                       }
                   }
               } 
           }
                              System.out.println(counter);

           if(counter == data.length()){
               
               if((current.isEndOfWord==true)&& checkingLinks(current)){
                   
                   return true;
               }
               else{
                    return false;
               }
           }
            //break;
        }
        return false;
    }
    public String getFromFile() {
        try{
            Scanner scan=new Scanner(System.in);
            System.out.println("Enter File name:");
            String fileName=scan.next();
            fileName+=".txt";
            FileReader newFile=new FileReader(fileName);
            BufferedReader read=new BufferedReader(newFile); 
            String allData="";
            String line=read.readLine();
            while(line!=null){
                allData+=line;
                line=read.readLine();
            }
             return allData;
        }
         catch( IOException e){
             System.out.println("file opening error!!");       
             return "";
         }
    }
    public void lowercase(String word){
        for(int i=0; i<word.length(); i++){
            if(word.charAt(i)>=65 && word.charAt(i)<=90){
                word.toLowerCase();
                
            }
        }
    }
    public static void main(String[] args) {
        Triedigitaltree a = new Triedigitaltree();
        String allData="";
        allData=a.getFromFile();
        allData.toLowerCase();
        long startTime=System.currentTimeMillis();
        for(String word: allData.split(" ")){
            
            a.insert(word);
        }
        long endTime=System.currentTimeMillis();
        System.out.println("Time taken in insertion:"+(endTime-startTime));

        
        long startTimeS=System.nanoTime();
        a.search("lorem");
        long endTimeS=System.nanoTime();
        System.out.println("Time taken in insertion:"+(endTimeS-startTimeS));

        long startTimef=System.nanoTime();
        a.search("eget");
        long endTimef=System.nanoTime();
        System.out.println("Time taken in insertion:"+(endTimef-startTimef));

    }
}

